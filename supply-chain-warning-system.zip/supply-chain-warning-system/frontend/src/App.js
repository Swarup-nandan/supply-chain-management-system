
import React from "react";
function App() {
  return (
    <div>
      <h1>Supply Chain Early Warning System</h1>
      <p>Frontend Setup Complete</p>
    </div>
  );
}
export default App;
