
from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
from sklearn.linear_model import LogisticRegression

app = FastAPI()

X = np.array([[5,10,2],[12,30,8],[2,5,1],[15,40,9]])
y = np.array([0,1,0,1])

model = LogisticRegression()
model.fit(X,y)

class InputData(BaseModel):
    delay: int
    demand_spike: int
    weather: int

@app.post("/predict")
def predict(data: InputData):
    prediction = model.predict([[data.delay,data.demand_spike,data.weather]])
    prob = model.predict_proba([[data.delay,data.demand_spike,data.weather]])
    return {"prediction": int(prediction[0]), "probability": float(prob[0][1])}
